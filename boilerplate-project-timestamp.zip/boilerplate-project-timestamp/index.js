const express = require('express');
const cors = require('cors');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors({ optionSuccessStatus: 200 }));
app.use(express.static('public'));

// Root route - serve HTML page
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Main API endpoint
app.get('/api/:date?', (req, res) => {
  let dateParam = req.params.date;
  let date;

  try {
    // Handle empty date parameter
    if (!dateParam) {
      date = new Date();
    } else {
      // Check if it's a Unix timestamp (all digits)
      if (/^\d+$/.test(dateParam)) {
        date = new Date(parseInt(dateParam));
      } else {
        // Try to parse as date string
        date = new Date(dateParam);
      }
    }

    // Check if date is valid
    if (isNaN(date.getTime())) {
      return res.json({ error: "Invalid Date" });
    }

    // Return the result
    res.json({
      unix: date.getTime(),
      utc: date.toUTCString()
    });

  } catch (error) {
    res.json({ error: "Invalid Date" });
  }
});

// 404 handler
app.use((req, res) => {
  res.status(404).json({ error: "Not Found" });
});

// Start server
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
  console.log(`Visit: https://${process.env.REPL_SLUG}.${process.env.REPL_OWNER}.repl.co`);
});